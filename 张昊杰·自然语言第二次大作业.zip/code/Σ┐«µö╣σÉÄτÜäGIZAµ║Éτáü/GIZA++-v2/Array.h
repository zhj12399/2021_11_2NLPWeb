#ifndef GIZA_ARRAY_H_DEFINED
#define GIZA_ARRAY_H_DEFINED
#include "Vector.h"
#define Array Vector
#endif
